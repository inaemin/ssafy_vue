package com.ssafy.mvc.jwt;

public class JwtTest {
	public static void main(String[] args) throws InterruptedException {

	}
}
